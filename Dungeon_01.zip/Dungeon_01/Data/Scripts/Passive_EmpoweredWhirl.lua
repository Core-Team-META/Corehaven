﻿local data = {}

data.name = "Empowered Whirl"
data.description = script:GetCustomProperty("Description")
data.icon = script:GetCustomProperty("Icon")

return data
