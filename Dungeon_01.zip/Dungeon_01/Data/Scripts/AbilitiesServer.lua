﻿local API_A = require(script:GetCustomProperty("APIAbility"))

API_A.Initialize(false)
