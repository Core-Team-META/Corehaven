﻿local data = {}

data.name = "Tough Skin"
data.damageTakenMultiplier = 0.8
data.description = script:GetCustomProperty("Description")
data.icon = script:GetCustomProperty("Icon")

return data
