﻿local data = {}

data.name = "Improved Rising Fury"
data.description = script:GetCustomProperty("Description")
data.icon = script:GetCustomProperty("Icon")

return data
