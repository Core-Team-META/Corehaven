﻿return {
  {
    Name = 'Leeching Brooch',
    Type = 'Trinket',
    Rarity = 'Rare',
    MUID = 'F0A24835A66FEB20:ITEM_Trinket_LeechingBrooch',
    Lore = 'Gives the wielder the power to steal a foes blood.',
    ['Author Notes (will be ignored by script)'] = '',
  },
  {
    Name = 'Warding Talisman',
    Type = 'Trinket',
    Rarity = 'Rare',
    MUID = '4CE2719F4F9C5B32:ITEM_Trinket_WardingTalisman',
    Lore = 'Can be used to grant a protective barrier to a friendly target.',
    ['Author Notes (will be ignored by script)'] = '',
  },
  {
    Name = 'Blight Bottle',
    Type = 'Trinket',
    Rarity = 'Rare',
    MUID = '5CEDECC0C70C3149:ITEM_Trinket_BlightBottle',
    Lore = 'A bottle of blight to throw at enemies.',
    ['Author Notes (will be ignored by script)'] = '',
  },
  {
    Name = 'Lucky Bone Band',
    Type = 'Trinket',
    Rarity = 'Rare',
    MUID = '7BC66566CAE382AE:ITEM_Trinket_LuckyBoneBand',
    Lore = 'Can be activated to greatly increase combat skill temporarily.',
    ['Author Notes (will be ignored by script)'] = '',
  },
}