﻿return {
  {
    Name = 'Leeching Brooch',
    Type = 'Trinket',
    Rarity = 'Rare',
    MUID = 'F0A24835A66FEB20:ITEM_Trinket_LeechingBrooch',
    Lore = '',
  },
  {
    Name = 'Warding Talisman',
    Type = 'Trinket',
    Rarity = 'Rare',
    MUID = '4CE2719F4F9C5B32:ITEM_Trinket_WardingTalisman',
    Lore = '',
  },
  {
    Name = 'Blight Bottle',
    Type = 'Trinket',
    Rarity = 'Rare',
    MUID = '5CEDECC0C70C3149:ITEM_Trinket_BlightBottle',
    Lore = '',
  },
  {
    Name = 'Lucky Bone Band',
    Type = 'Trinket',
    Rarity = 'Rare',
    MUID = '7BC66566CAE382AE:ITEM_Trinket_LuckyBoneBand',
    Lore = '',
  },
}