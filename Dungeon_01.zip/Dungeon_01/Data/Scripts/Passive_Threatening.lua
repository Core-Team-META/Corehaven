﻿local data = {}

data.name = "Threatening"
data.threatMultiplier = 4.0
data.description = script:GetCustomProperty("Description")
data.icon = script:GetCustomProperty("Icon")

return data
